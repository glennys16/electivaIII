<?php
$servername = "localhost";
$database = "concejo";
$username = "root";
$password = "123456789";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection

?>
