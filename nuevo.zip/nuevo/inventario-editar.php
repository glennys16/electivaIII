<?php
include("conexion.php");
include("head.php");

if (isset($_POST['enviar'])) {
    
    $id = $_POST["id"];
    $codigo = $_POST["codigo"];
$nombre = $_POST["nombre"];
$departamento = $_POST["departamento"];
$descripcion = $_POST["descripcion"];

// Verificar si la cédula ya existe
$consulta_verificacion = "SELECT COUNT(*) FROM inventario WHERE codigo = '$codigo'";
$resultado_verificacion = mysqli_query($conn, $consulta_verificacion);
$registros_iguales = mysqli_fetch_row($resultado_verificacion)[0];

if ($registros_iguales > 0) {
  echo "<script language='JavaScript'>
  alert('El codigo ya existe');
  location.assign('inventario-reporte.php');
  </script> ";
    exit();
}

$sql = "UPDATE inventario SET id='".$id."', codigo='".$codigo."', nombre='".$nombre."', departamento='".$departamento."' , descripcion='".$descripcion."' WHERE id='".$id."'";
$resultado = mysqli_query($conn, $sql);

if($resultado){
    echo "<script language='JavaScript'>
            alert('correctamente');
            location.assign('inventario-reporte.php');
            </script> ";

}else{
  echo "<script language='JavaScript'>
  alert('no correctamente');
  location.assign('inventario-reporte.php');
  </script> ";

}
mysqli_close($conn);
} else {
  $id = $_GET['id'];
  $sql = "SELECT * FROM inventario WHERE id=" . $id; // Use prepared statement for security
  $resultado = mysqli_query($conn, $sql);

  $row = mysqli_fetch_assoc($resultado);
  $codigo = $row["codigo"];
  $nombre = $row["nombre"];
  $departamento = $row["departamento"];
  $descripcion = $row["descripcion"];

  mysqli_close($conn); // Close connection here after using it
}
?>
<div class="container-fluid py-4">
      <div class="row">
      <div class="col-12">
            <div class="card card-plain mb-4">
            <div class="card-body p-3">
                <div class="row">
                <div class="col-lg-6">
                    <div class="d-flex flex-column h-100">
                    <h2 class="font-weight-bolder mb-0">Actualizar Inventario</h2>
                    </div>
                </div>
                </div>
            </div>
            </div>
    </div>
    <div class="col-6">
      <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
        <div class="input-group input-group-outline mb-4">
          <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
        </div>
        <div class="input-group input-group-outline mb-4">
          <label class="form-label editar">codigo</label>
          <input type="text" class="form-control" name="codigo" value="<?php echo $codigo; ?>">
        </div>
        <div class="input-group input-group-outline mb-4">
          <label class="form-label editar">Nombre</label>
          <input type="text" class="form-control" name="nombre" value="<?php echo $nombre; ?>">
        </div>
        <div class="input-group input-group-outline mb-4">
          <label class="form-label editar">departamento</label>
          <input type="text" class="form-control" name="departamento" value="<?php echo $departamento; ?>">
        </div>
        <div class="input-group input-group-outline mb-4">
          <label class="form-label editar">descripcion</label>
          <input type="text" class="form-control" name="descripcion" value="<?php echo $descripcion; ?>">
        </div>

        <input type="submit" class="btn btn-success btn-lg" value="Actualizar" name="enviar">
        <a href="inventario-reporte.php" class="btn btn-primary btn-lg">Regresar</a>
      </form>
    </div>
  </div>
</div>

<?php
include("footer.php");
?>
