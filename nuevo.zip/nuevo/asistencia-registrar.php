<?php

// Establecer conexión con la base de datos
include("conexion.php");

// Comprobar la conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Recibir datos del formulario
$cedula = $_POST["cedula"];
$nombre = $_POST["nombre"];
$cargo = $_POST["cargo"];

// Verificar si la cédula ya existe
$consulta_verificacion = "SELECT COUNT(*) FROM registro WHERE cedula = '$cedula'";
$resultado_verificacion = mysqli_query($conn, $consulta_verificacion);
$registros_iguales = mysqli_fetch_row($resultado_verificacion)[0];

if ($registros_iguales > 0) {
    echo "Error: La cédula ya existe.";
    exit();
}

// Insertar el registro solo si la cédula no existe
$sql = "INSERT INTO registro (cedula, nombre, cargo) VALUES ('$cedula', '$nombre', '$cargo')";

// Ejecutar la consulta SQL
if (mysqli_query($conn, $sql)) {
    echo "<script language='JavaScript'>
            alert('Registro correctamente');
            location.assign('asistencia.php');
            </script> ";
            
   
    
    
} else {
    echo "Error al registrar: " . mysqli_error($conn);
}

// Cerrar la conexión
mysqli_close($conn);

?>
