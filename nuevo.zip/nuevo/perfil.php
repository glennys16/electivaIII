<?php

session_start();


if (!isset($_SESSION['loggedin'])) {

    header('Location: login.php');
    exit;
}


include("conexion.php");

if (mysqli_connect_error()) {

    // si se encuentra error en la conexión

    exit('Fallo en la conexión de MySQL:' . mysqli_connect_error());
}

$stmt = $conn->prepare('SELECT password, id FROM logueo WHERE id = ?');





$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($password, $username);
$stmt->fetch();
$stmt->close();


?>





<?php include("head.php");  ?>
  
<div class="container-fluid px-2 px-md-4">
<div class="page-header min-height-300 border-radius-xl mt-4" style="background-image: url('https://images.unsplash.com/photo-1531512073830-ba890ca4eba2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;ixlib=rb-1.2.1&amp;auto=format&amp;fit=crop&amp;w=1920&amp;q=80');">
<span class="mask  bg-gradient-primary  opacity-6"></span>
</div>
<div class="card card-body mx-3 mx-md-4 mt-n6">
    <div class="row gx-4 mb-2">
        <div class="col-auto">
            <div class="avatar avatar-xl position-relative">
                <img src="/assets/img/bruce-mars.jpg" alt="profile_image" class="w-100 border-radius-lg shadow-sm">
            </div>
        </div>
        <div class="col-auto my-auto">
            <div class="h-100">
                <h5 class="mb-1">
                Información del Usuario
                </h5>
                <p class="mb-0 font-weight-normal text-sm  text-uppercase">
                <td ><?= $_SESSION['name'] ?></td>
                </p>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-12 col-xl-4">
            <div class="card card-plain h-100">
                <div class="card-header pb-0 p-3">
                    <div class="row">
                        <div class="col-md-8 d-flex align-items-center">
                            <h6 class="mb-0">Prefil</h6>
                        </div>
                        <div class="col-md-4 text-end">
                        <?php echo "<a href='editar_sesion.php?id=".$_SESSION['id']."'><i class='fas fa-user-edit text-secondary text-sm' data-bs-toggle='tooltip' data-bs-placement='top' aria-hidden='true' aria-label='Edit Profile' data-bs-original-title='Edit Profile'></i><span class='sr-only'>Edit Profile</span></a>"; ?>
                            
                            
                        </div>        
                    </div>
                    <div class="card-body p-3">
                        <p class="text-sm">
                        Bienvenidos super usuario</p>
                        <hr class="horizontal gray-light my-4">
                            <ul class="list-group">
                                <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong class="text-dark">Cargo</strong> &nbsp; <?= $_SESSION['permisos'] ?></li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Permisos</strong> &nbsp; TOTAL</li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>