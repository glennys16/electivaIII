<?php include("conexion.php");  ?>

<?php include("head.php");  ?>
<div class="container">
  <div class="row">
    <div class="col-12">
            <div class="card card-plain mb-4">
            <div class="card-body p-3">
                <div class="row">
                <div class="col-lg-6">
                    <div class="d-flex flex-column h-100">
                    <h2 class="font-weight-bolder mb-0">Registro Inventario</h2>
                    </div>
                </div>
                </div>
            </div>
            </div>
    </div>

    <div class="col-6 ">
      <form action="inventario-registrar.php" method="post">
          <div class="input-group input-group-outline mb-4">
            <label class="form-label">Codigo</label>
            <input type="text" class="form-control" name="codigo">
          </div>

          <div class="input-group input-group-outline mb-4">
            <label class="form-label">Nombre</label>
            <input type="text" class="form-control" name="nombre">
          </div>

          <div class="input-group input-group-outline mb-4">
          <label class="form-label">Descripción</label>
            <input type="text" class="form-control" name="descripcion">
          </div>
          <div class="input-group input-group-outline mb-4">
          <label class="form-label">Departamento</label>
            <input type="text" class="form-control" name="departamento">
          </div>
          <input type="submit" class="btn btn-success btn-lg" value="Registrar">
        </form>
    </div>
  </div>
</div>

<?php include("footer.php");  ?>