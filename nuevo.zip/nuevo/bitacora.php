<?php include("head.php");  ?>

<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
              <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <h6 class="text-white text-capitalize ps-3">Bitacora</h6>
                <a class="btn btn-outline-primary " href="fpdf/reporte-i.php" target="_blank" type="button" style="border-color: #fff; color: #fff; float: right; position: relative; bottom: 35px;  margin-right: 20px;">Exportar</a>
              </div>
            </div>
            <div class="card-body px-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    
                    <tr>
                      <th class="align-middle text-center">#</th>
                      <th class="align-middle text-center">USUARIO</th>
                      <th class="align-middle text-center">FECHA INICIO SESION</th>
                      <th class="align-middle text-center">FECHA CIERRE SESION</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php // Preparar la consulta SQL
                  include("conexion.php");
                $sql = "SELECT * FROM bitacora";

                // Ejecutar la consulta SQL
                $resultado = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($resultado)) {
            ?>
                <tr>
                    <th class="align-middle text-center"><?php echo $row['id'] ?></th> 
                    <th class="align-middle text-center"><?php echo $row['id_usuario'] ?></th>                   
                    <th class="align-middle text-center"><?php echo $row['fecha_inicio'] ?></th>
                    <th class="align-middle text-center"><?php echo $row['fecha_fin'] ?></th>
                </tr>
            <?php
            }
            ?>
             
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
      
      <?php include("footer.php");  ?>