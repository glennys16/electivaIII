
<?php include("head.php");  ?>
<div class="p-4">
  <form>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Cedula</label>
      <input type="text" class="form-control">
    </div>

    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Nombre</label>
      <input type="text" class="form-control">
    </div>

    <div class="input-group input-group-outline mb-4">
    <label class="form-label">Cargo</label>
      <input type="text" class="form-control">
    </div>
  </form>
</div>

<?php include("footer.php");  ?>