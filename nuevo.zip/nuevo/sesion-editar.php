<?php
include("conexion.php");
include("head.php");

if (isset($_POST['enviar'])) {
    
    $id = $_POST["id"];
    $username = $_POST["username"];
$password = $_POST["password"];
$permisos = $_POST["permisos"];

// Verificar si el nombre de usuario ya existe
$consulta_verificacion = "SELECT COUNT(*) FROM logueo WHERE username = '$username'";
$resultado_verificacion = mysqli_query($conn, $consulta_verificacion);
$registros_iguales = mysqli_fetch_row($resultado_verificacion)[0];

if ($registros_iguales > 0) {
    echo "<script language='JavaScript'>
    alert('Usuario ya existe');
    location.assign('sesion-inicio.php');
    </script> ";
    exit();
}

$sql = "UPDATE logueo SET id='".$id."', username='".$username."', password='".$password."', permisos='".$permisos."' WHERE id='".$id."'";
$resultado = mysqli_query($conn, $sql);

if($resultado){
    echo "<script language='JavaScript'>
            alert('correctamente');
            location.assign('sesion-inicio.php');
            </script> ";

}else{
  echo "<script language='JavaScript'>
  alert('no correctamente');
  location.assign('sesion-inicio.php');
  </script> ";

}
mysqli_close($conn);
} else {
  $id = $_GET['id'];
  $sql = "SELECT * FROM logueo WHERE id=" . $id; // Use prepared statement for security
  $resultado = mysqli_query($conn, $sql);

  $row = mysqli_fetch_assoc($resultado);
  $username = $row["username"];
  $password = $row["password"];
  $permisos = $row["permisos"];

  mysqli_close($conn); // Close connection here after using it
}
?>
<div class="container">
  <div class="row">
    <div class="col-12">
            <div class="card card-plain mb-4">
            <div class="card-body p-3">
                <div class="row">
                <div class="col-lg-6">
                    <div class="d-flex flex-column h-100">
                    <h2 class="font-weight-bolder mb-0">Actualizar Usuario</h2>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>

    <div class="col-6 ">
      <div class="p-4">
        <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
          <div class="input-group input-group-outline mb-4">
            <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
          </div>
          <div class="input-group input-group-outline mb-4">
            <label class="form-label editar">username</label>
            <input type="text" class="form-control" name="username" value="<?php echo $username; ?>">
          </div>
          <div class="input-group input-group-outline mb-4">
            <label class="form-label editar">password</label>
            <input type="text" class="form-control" name="password" value="">
          </div>
          <div class="input-group input-group-outline mb-4">
                  <label class="form-label editar">Permisos</label>
                      <select class="form-control" name="permisos" id="" >
                          <option>Selecionar</option>
                          <option value="admin">Admin</option>
                          <option value="suplente">Suplente</option>
                      </select>
              
                  </div>

          <input type="submit" class="btn btn-success btn-lg" value="Actualizar" name="enviar">
          <a href="sesion-inicio.php" class="btn btn-primary btn-lg">Regresar</a>
        </form>
      </div>
  </div>
</div>

<?php
include("../footer.php");
?>
