<?php

// Establecer conexión con la base de datos
include("conexion.php");

// Comprobar la conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Recibir datos del formulario
$codigo = $_POST["codigo"];
$nombre = $_POST["nombre"];
$descripcion = $_POST["descripcion"];
$departamento = $_POST["departamento"];

// Verificar si la cédula ya existe
$consulta_verificacion = "SELECT COUNT(*) FROM inventario WHERE codigo = '$codigo'";
$resultado_verificacion = mysqli_query($conn, $consulta_verificacion);
$registros_iguales = mysqli_fetch_row($resultado_verificacion)[0];

if ($registros_iguales > 0) {
    echo "Error: el codigo ya existe.";
    exit();
}

// Insertar el registro solo si la cédula no existe
$sql = "INSERT INTO inventario (codigo, nombre, descripcion, departamento) VALUES ('$codigo', '$nombre', '$descripcion', '$departamento')";

// Ejecutar la consulta SQL
if (mysqli_query($conn, $sql)) {
    header('Location: inventario.php');
} else {
    echo "Error al registrar: " . mysqli_error($conn);
}

// Cerrar la conexión
mysqli_close($conn);

?>
