<?php
$id=$_GET['id'];
include("conexion.php");

$sql = "DELETE FROM inventario WHERE id='".$id."'";
$resultado = mysqli_query($conn, $sql);

if($resultado){
    echo "<script language='JavaScript'>
            alert('Elimi correctamente');
            location.assign('inventario-reporte.php');
            </script> ";

}else{
  echo "<script language='JavaScript'>
  alert('no correctamente');
  location.assign('inventario-reporte.php');
  </script> ";

}

?>