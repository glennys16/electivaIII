<?php include("head.php");  ?>

    
<div class="container-fluid">
  <div class="row">
    <form action="" method="post">
      <div class="col-12">
        <div class="row">
          <div class="col-6">
            <label for="">Visión</label>
            <textarea name="vision" id="" cols="50" rows="5">

            </textarea>
          </div>
          <div class="col-6">
          <label for="">Misión</label>
            <textarea name="mision" id="" cols="50" rows="5">

            </textarea>
          </div>
          <div class="col-6">
          <label for="">Logo</label>
            <input type="file" id="logo" accept="image/*" />
          </div>
          <div class="col-6">
            <label for="">Color</label>
              <input type="color" name="color" id="">
          </div>
        </div>
        <input type="submit" class="btn btn-success btn-lg" value="Guardar" name="enviar">
      </div>

    </form>
  </div>
</div>
<?php include("footer.php");  ?>

<?php

// Establecer conexión con la base de datos
include("conexion.php");

// Comprobar la conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}
if (isset($_POST['enviar'])) {
// Recibir datos del formulario
$vision = $_POST["vision"];
$mision = $_POST["mision"];
$logo = $_POST["logo"];
$color = $_POST["color"];




$sql = "UPDATE cmp SET vision='".$vision."', mision='".$mision."', logo='".$logo."' , color='".$color."' WHERE id='1'";

// Ejecutar la consulta SQL
if (mysqli_query($conn, $sql)) {
    echo "<script language='JavaScript'>
            alert('Actualización correctamente');
            location.assign('concejo.php');
            </script> ";
            
   
    
    
} else {
    echo "Error al registrar: " . mysqli_error($conn);
}
}
// Cerrar la conexión
mysqli_close($conn);

?>
