<?php include("conexion.php");  ?>

<?php include("head.php");  ?>
<div class="container">
  <div class="row">
    <div class="col-12">
          <div class="card card-plain mb-4">
            <div class="card-body p-3">
                <div class="row">
                <div class="col-lg-6">
                    <div class="d-flex flex-column h-100">
                    <h2 class="font-weight-bolder mb-0">Registro Asistencia</h2>
                    </div>
                </div>
                </div>
            </div>
          </div>
      </div>

    <div class="col-6 ">
      <form action="asistencia-registrar.php" method="post">
        <div class="input-group input-group-outline mb-4">
          <label class="form-label">Cedula</label>
          <input type="text" class="form-control" name="cedula">
        </div>

        <div class="input-group input-group-outline mb-4">
          <label class="form-label">Nombre</label>
          <input type="text" class="form-control" name="nombre">
        </div>

        <div class="input-group input-group-outline mb-4">
        <label class="form-label">Cargo</label>
          <input type="text" class="form-control" name="cargo">
        </div>
        
        <input type="submit" class="btn btn-success btn-lg" value="Registrar">
      </form>
    </div>
  </div>
</div>

<?php include("footer.php");  ?>