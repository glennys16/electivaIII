
<?php include("head.php");  ?>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
              <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <h6 class="text-white text-capitalize ps-3">Personal</h6>
              </div>
            </div>
            <div class="card-body px-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    
                    <tr>
                      <th class="align-middle text-center">#</th>
                      <th class="align-middle text-center">Nombre</th>
                      <th class="align-middle text-center">Cedula</th>
                      <th class="align-middle text-center">Cargo</th>
                      <th class="align-middle text-center">Fecha</th>
                      <th class="align-middle text-center"></th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php // Preparar la consulta SQL
                  include("conexion.php");
                $sql = "SELECT * FROM registro";

                // Ejecutar la consulta SQL
                $resultado = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($resultado)) {
            ?>
                <tr>
                    <th class="align-middle text-center"><?php echo $row['id'] ?></th>                    
                    <th class="align-middle text-center"><?php echo $row['nombre'] ?></th>
                    <th class="align-middle text-center"><?php echo $row['cedula'] ?></th>
                    <th class="align-middle text-center"><?php echo $row['cargo'] ?></th>
                    <th class="align-middle text-center"><?php echo $row['fecha'] ?></th>
                    <th class="align-middle text-center">
                    <?php echo "<a href='editar_personal.php?id=".$row['id']."'>Editar</a>"; ?>
                    </th>
                    <th class="align-middle text-center"><a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                          Elimi
                        </a>
                    </th>
                </tr>
            <?php
            }
            ?>
             
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
      
      <?php include("footer.php");  ?>