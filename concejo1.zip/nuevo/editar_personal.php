<?php
include("conexion.php");
include("head.php");

if (isset($_POST['enviar'])) {
  // Handle form submission logic here (update query, etc.)
} else {
  $id = $_GET['id'];
  $sql = "SELECT * FROM registro WHERE id=" . $id; // Use prepared statement for security
  $resultado = mysqli_query($conn, $sql);

  $row = mysqli_fetch_assoc($resultado);
  $cedula = $row["cedula"];
  $nombre = $row["nombre"];
  $cargo = $row["cargo"];


}
?>

<div class="p-4">
  <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
    <div class="input-group input-group-outline mb-4">
      <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Cedula</label>
      <input type="text" class="form-control" name="cedula" value="<?php echo $cedula; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Nombre</label>
      <input type="text" class="form-control" name="nombre" value="<?php echo $nombre; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Cargo</label>
      <input type="text" class="form-control" name="cargo" value="<?php echo $cargo; ?>">
    </div>

    <input type="submit" class="btn btn-success btn-lg" value="Actualizar" name="enviar">
    <a href="personal.php">Regresar</a>
  </form>
</div>

<?php
include("footer.php");
?>
