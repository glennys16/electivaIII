<?php

// Establecer conexión con la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "concejo";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprobar la conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Recibir datos del formulario
$cedula = $_POST["cedula"];
$nombre = $_POST["nombre"];
$cargo = $_POST["cargo"];

// Preparar la consulta SQL
$sql = "INSERT INTO registro (cedula, nombre, cargo) VALUES ('$cedula', '$nombre', '$cargo')";

// Ejecutar la consulta SQL
if (mysqli_query($conn, $sql)) {
    header('Location: personal.php');
} else {
    echo "Error al registrar: " . mysqli_error($conn);
}

// Cerrar la conexión
mysqli_close($conn);

?>
