<?php include("../conexion.php");  ?>

<?php include("../head.php");  ?>

<div class="p-4">
<form action="registrar_i.php" method="post">
    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Codigo</label>
      <input type="text" class="form-control" name="codigo">
    </div>

    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Nombre</label>
      <input type="text" class="form-control" name="nombre">
    </div>

    <div class="input-group input-group-outline mb-4">
    <label class="form-label">Descripción</label>
      <input type="text" class="form-control" name="descripcion">
    </div>
    <div class="input-group input-group-outline mb-4">
    <label class="form-label">Departamento</label>
      <input type="text" class="form-control" name="departamento">
    </div>
    <input type="submit" class="btn btn-success btn-lg" value="Registrar">
  </form>
  </div>

<?php include("../footer.php");  ?>