<?php
include("../conexion.php");
include("../head.php");

if (isset($_POST['enviar'])) {
    
    $id = $_POST["id"];
    $codigo = $_POST["codigo"];
$nombre = $_POST["nombre"];
$departamento = $_POST["departamento"];
$descripcion = $_POST["descripcion"];

$sql = "UPDATE inventario SET id='".$id."', codigo='".$codigo."', nombre='".$nombre."', departamento='".$departamento."' , descripcion='".$descripcion."' WHERE id='".$id."'";
$resultado = mysqli_query($conn, $sql);

if($resultado){
    echo "<script language='JavaScript'>
            alert('correctamente');
            location.assign('reporte_i.php');
            </script> ";

}else{
  echo "<script language='JavaScript'>
  alert('no correctamente');
  location.assign('reporte_i.php');
  </script> ";

}
mysqli_close($conn);
} else {
  $id = $_GET['id'];
  $sql = "SELECT * FROM inventario WHERE id=" . $id; // Use prepared statement for security
  $resultado = mysqli_query($conn, $sql);

  $row = mysqli_fetch_assoc($resultado);
  $codigo = $row["codigo"];
  $nombre = $row["nombre"];
  $departamento = $row["departamento"];
  $descripcion = $row["descripcion"];

  mysqli_close($conn); // Close connection here after using it
}
?>

<div class="p-4">
  <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
    <div class="input-group input-group-outline mb-4">
      <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label editar">codigo</label>
      <input type="text" class="form-control" name="codigo" value="<?php echo $codigo; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label editar">Nombre</label>
      <input type="text" class="form-control" name="nombre" value="<?php echo $nombre; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label editar">departamento</label>
      <input type="text" class="form-control" name="departamento" value="<?php echo $departamento; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label editar">descripcion</label>
      <input type="text" class="form-control" name="descripcion" value="<?php echo $descripcion; ?>">
    </div>

    <input type="submit" class="btn btn-success btn-lg" value="Actualizar" name="enviar">
    <a href="inventario.php">Regresar</a>
  </form>
</div>

<?php
include("../footer.php");
?>
