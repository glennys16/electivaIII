<?php

// Establecer conexión con la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "concejo";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprobar la conexión
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Recibir datos del formulario
$codigo = $_POST["codigo"];
$nombre = $_POST["nombre"];
$descripcion = $_POST["descripcion"];
$departamento = $_POST["departamento"];

// Preparar la consulta SQL
$sql = "INSERT INTO inventario (codigo, nombre, descripcion, departamento) VALUES ('$codigo', '$nombre', '$descripcion', '$departamento')";

// Ejecutar la consulta SQL
if (mysqli_query($conn, $sql)) {
    header('Location: inventario.php');
} else {
    echo "Error al registrar: " . mysqli_error($conn);
}

// Cerrar la conexión
mysqli_close($conn);

?>
