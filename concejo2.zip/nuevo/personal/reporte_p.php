
<?php include("../head.php");  ?>
<script >
  function confirmar(){
    return confirm('Estas seguro de eliminar');
    
  }
</script>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card my-4">
            <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
              <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                <h6 class="text-white text-capitalize ps-3">Personal</h6>
              </div>
            </div>
            <div class="card-body px-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    
                    <tr>
                      <th class="align-middle text-center">#</th>
                      <th class="align-middle text-center">Nombre</th>
                      <th class="align-middle text-center">Cedula</th>
                      <th class="align-middle text-center">Cargo</th>
                      <th class="align-middle text-center">Fecha</th>
                      <th class="align-middle text-center"></th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php // Preparar la consulta SQL
                  include("../conexion.php");
                $sql = "SELECT * FROM registro";

                // Ejecutar la consulta SQL
                $resultado = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($resultado)) {
            ?>
                <tr>
                    <th class="align-middle text-center"><?php echo $row['id'] ?></th>                    
                    <th class="align-middle text-center"><?php echo $row['nombre'] ?></th>
                    <th class="align-middle text-center"><?php echo $row['cedula'] ?></th>
                    <th class="align-middle text-center"><?php echo $row['cargo'] ?></th>
                    <th class="align-middle text-center"><?php echo $row['fecha'] ?></th>
                    <th class="align-middle text-center">
                    <?php echo "<a href='editar_p.php?id=".$row['id']."'><i class='material-icons text-md me-2 mr-3'>edit</i></a>"; ?>
                    
                    <?php echo "<a href='eliminar_p.php?id=".$row['id']."' onclick='return confirmar()'><i class='material-icons text-md me-2 ml-3'>delete</i></a>"; ?>
                       
                    </th>
                </tr>
            <?php
            }
            ?>
             
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
      
      <?php include("../footer.php");  ?>