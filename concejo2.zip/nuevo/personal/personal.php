<?php include("../conexion.php");  ?>

<?php include("../head.php");  ?>

<div class="p-4">
<form action="registrar_p.php" method="post">
    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Cedula</label>
      <input type="text" class="form-control" name="cedula">
    </div>

    <div class="input-group input-group-outline mb-4">
      <label class="form-label">Nombre</label>
      <input type="text" class="form-control" name="nombre">
    </div>

    <div class="input-group input-group-outline mb-4">
    <label class="form-label">Cargo</label>
      <input type="text" class="form-control" name="cargo">
    </div>
    
    <input type="submit" class="btn btn-success btn-lg" value="Registrar">
  </form>
</div>

<?php include("../footer.php");  ?>