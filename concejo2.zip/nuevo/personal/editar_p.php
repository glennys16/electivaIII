<?php
include("../conexion.php");
include("../head.php");

if (isset($_POST['enviar'])) {
    
    $id = $_POST["id"];
    $cedula = $_POST["cedula"];
$nombre = $_POST["nombre"];
$cargo = $_POST["cargo"];

$sql = "UPDATE registro SET id='".$id."', cedula='".$cedula."', nombre='".$nombre."', cargo='".$cargo."' WHERE id='".$id."'";
$resultado = mysqli_query($conn, $sql);

if($resultado){
    echo "<script language='JavaScript'>
            alert('correctamente');
            location.assign('reporte_p.php');
            </script> ";

}else{
  echo "<script language='JavaScript'>
  alert('no correctamente');
  location.assign('reporte_p.php');
  </script> ";

}
mysqli_close($conn);
} else {
  $id = $_GET['id'];
  $sql = "SELECT * FROM registro WHERE id=" . $id; // Use prepared statement for security
  $resultado = mysqli_query($conn, $sql);

  $row = mysqli_fetch_assoc($resultado);
  $cedula = $row["cedula"];
  $nombre = $row["nombre"];
  $cargo = $row["cargo"];

  mysqli_close($conn); // Close connection here after using it
}
?>

<div class="p-4">
  <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
    <div class="input-group input-group-outline mb-4">
      <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label editar">Cedula</label>
      <input type="text" class="form-control" name="cedula" value="<?php echo $cedula; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label editar">Nombre</label>
      <input type="text" class="form-control" name="nombre" value="<?php echo $nombre; ?>">
    </div>
    <div class="input-group input-group-outline mb-4">
      <label class="form-label editar">Cargo</label>
      <input type="text" class="form-control" name="cargo" value="<?php echo $cargo; ?>">
    </div>

    <input type="submit" class="btn btn-success btn-lg" value="Actualizar" name="enviar">
    <a href="personal.php">Regresar</a>
  </form>
</div>

<?php
include("../footer.php");
?>
